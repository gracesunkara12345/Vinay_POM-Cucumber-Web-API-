package Base;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;
 

public class RunTest {
	
	private WebDriver driver;
	private LoginPageTest loginPage;
	
	
	@BeforeTest
	public void test1()
	{
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://192.168.1.65:8080/Recruitex_Sales/#/login");
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.SECONDS);
	}
	
	@Test
	public void test2()
	{
		loginPage = new LoginPageTest(driver);
		loginPage.login("Vinay", "Kumar");
	}
	
	@AfterTest
	public void teardown()
	{
		driver.close();
	}

}

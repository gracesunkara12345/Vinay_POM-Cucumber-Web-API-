package Base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPageTest {
	
	 private WebDriver driver;

	    public LoginPageTest(WebDriver driver) {
	        this.driver = driver;
	        PageFactory.initElements(driver, this);
	    }

	    @FindBy(name = "email")
	    private WebElement usernameInput;

	    @FindBy(name = "password")
	    private WebElement passwordInput;

	    @FindBy(id = "loginButton")
	    private WebElement loginButton;

	    public void login(String username, String password) {
	        usernameInput.sendKeys(username);
	        passwordInput.sendKeys(password);
	        loginButton.click();
	    }

}

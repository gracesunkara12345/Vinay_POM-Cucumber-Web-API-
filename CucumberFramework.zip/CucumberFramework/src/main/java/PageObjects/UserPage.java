package PageObjects;

public class UserPage {

}

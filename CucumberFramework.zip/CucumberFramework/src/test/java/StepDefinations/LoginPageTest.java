package StepDefinations;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginPageTest {
	
	public WebDriver driver;
	
	@Given("User is on Login Page")
	public void user_is_on_login_page() {
	   WebDriverManager.edgedriver().setup();
	   driver = new EdgeDriver();
	   driver.get("http://192.168.1.65:8080/Recruitex_Sales/#/login");
	   driver.manage().window().maximize();
	}

	@When("Enter Username and Password")
	public void enter_username_and_password() {
	   driver.findElement(By.name("email")).sendKeys("jayaram.yedla@ojas-it.com");
	   driver.findElement(By.name("password")).sendKeys("8897503250");
	}

	@When("Click on Login button")
	public void click_on_login_button() {
	   driver.findElement(By.xpath("//button[text()=' Login']")).click();
	}

	@Then("User is navigated to HomePage")
	public void user_is_navigated_to_home_page() {
	  System.out.println("Navigated to HomePage");
	  driver.close();
	   
	}


}

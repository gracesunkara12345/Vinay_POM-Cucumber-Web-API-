package StepDefinations;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class MultipleLoginTest {
	
	public WebDriver driver;
	
	@Given("Open RecuitX login page")
	public void open_recuit_x_login_page() {
		 WebDriverManager.edgedriver().setup();
		   driver = new EdgeDriver();
		   driver.get("http://192.168.1.65:8080/Recruitex_Sales/#/login");
		   driver.manage().window().maximize();
	}

	@When("^Enter (.*) and (.*)$")
	public void enter_mohan_talari_ojas_it_com_and_mohan(String username, String password) {
		 driver.findElement(By.name("email")).sendKeys(username);
		 driver.findElement(By.name("password")).sendKeys(password);
	}
	
	@And("Click on Login")
	public void loginButton()
	{
	 driver.findElement(By.xpath("//button[text()=' Login']")).click();
	}

	@Then("Validate Home page")
	public void validate_home_page() {
	    System.out.println("Navigated to HomePage");
	    driver.close();
	}

}

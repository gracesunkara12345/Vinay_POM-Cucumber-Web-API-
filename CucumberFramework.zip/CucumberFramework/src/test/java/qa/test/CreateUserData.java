package qa.test;

import io.cucumber.java.en.*;
import Utils.ReusableMethods;
import org.openqa.selenium.WebDriver;
import PageObjects.LoginPage;

public class CreateUserData extends ReusableMethods {

	private LoginPage loginPage;
	private WebDriver driver;
	
	@Given("Login to RecuitX and Navigate to Customer page")
	public void Login_to_RecuitX_and_Navigate_to_Customer_page()
	{
		loginPage = new LoginPage(driver);
		browserInitialize();
		loginPage.login("Vinay", "Kumar");
	}
	
	@When("Fill all mandatory fileds and click save")
	public void Fill_all_mandatory_fileds_and_click_save()
	{
      System.out.println("When");
	}
	
	@Then("Validate User is created Successfully")
	public void Validate_User_is_created_Successfully()
	{
		System.out.println("Test3 Pass");
	}

}

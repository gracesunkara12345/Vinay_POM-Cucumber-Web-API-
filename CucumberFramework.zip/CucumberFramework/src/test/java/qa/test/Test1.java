package qa.test;

import io.cucumber.java.en.*;

public class Test1 {
	
	@Given("Navigate to user page")
	public void navigate_to_user_page() {
	    
	}

	@When("fill all mandatory fields")
	public void fill_all_mandatory_fields() {
	   
	}

	@When("Click on Ok")
	public void click_on_ok() {
	   
	}

	@Then("Validate User is added successfully")
	public void validate_user_is_added_successfully() {
	    
	}

}

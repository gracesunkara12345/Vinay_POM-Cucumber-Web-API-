import faker from 'faker';
import NewTechnology from "../POMObjects/Admin/NewTechObj"
import FillTimeSheets from "../POMObjects/User/FillTimeSheetOb"
describe('Add New Tech', () => {
    const clientName = faker.company.companyName()
    it('Add New Tech and Validate Tech is added Successfully', () => {    
      const nt = new NewTechnology()
      nt.visitNewTech()
      cy.get('label > input').type(clientName)
      cy.wait(3000)
      cy.get('#techName').type(clientName)
      cy.get('#submitbtnRegion').click()
      cy.wait(3000)
      cy.get('label > input').type(clientName)
      cy.wait(3000)
      cy.get('#username').click()
      cy.get(':nth-child(5) > .dropdown-item').click()
    })

    it('New Tech and Validate Tech in User', () => {

     const ft = new FillTimeSheets()
     ft.visitTimeSheet()
     const dropdown = clientName.toLowerCase();
     cy.get('#domain').select(dropdown)
     cy.log(dropdown)

    })
})
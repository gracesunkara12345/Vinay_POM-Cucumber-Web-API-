import faker from 'faker';
import NewRole from "../../POMObjects/Admin/NewRoleObjects"
describe('Add New Role', () => {
    it('Adding a new Role with Admin Credentials', () => {
       
        const nr = new NewRole()
        nr.visitNewRole()

        // Faker Data
        const empId  = faker.random.number({ min: 21000, max: 21999 });
        const firstName = faker.name.firstName();
        const lastName = faker.name.lastName();
        const empName = `${firstName} ${lastName}`;
        const email = `${lastName}.${firstName}@ojas-it.com`
        const phNo = faker.random.number({ min: 900000000, max: 9999999999 });
        const gender = faker.random.number({ min: 1, max: 2 });
        const empImage = faker.image.imageUrl();
        
        // Add New Client
        cy.get('#empId').type(empId)
        cy.get('#empName').type(empName)
        cy.get('#emailId').type(email)
        cy.get('#password').type('Ojas@15251525');
        cy.get('#domain').find('option').then(options => {
        const numberOfOptions = options.length;
        const designation = faker.random.number({ min: 1, max: numberOfOptions - 1 });
        cy.get('#domain').select(designation);
        });

        cy.get('#phoneNumber').type(phNo)
        cy.get('#role').find('option').then(options => {
        const numb = options.length;
        const roles = faker.random.number({ min: 1, max: numb - 1 });
        cy.get('#role').select(roles)
        })
        cy.wait(2000)
        cy.fixture('car.jpg').then((fileContent) => {
          cy.get('#userpic').attachFile({
            fileContent,
            fileName: 'car.jpg',
            mimeType: 'image/jpg',
          });
        });
       
        cy.get(`#option${gender}`).click()

        cy.get('.col-12 > .btn').click()

    })

})
import faker from 'faker';
import FillTimeSheets from '../../POMObjects/User/FillTimeSheetOb'
describe('Add New Role', () => {
    it('Adding a new Role with Admin Credentials', () => {
       
        const ft = new FillTimeSheets()
        ft.visitTimeSheet()
        cy.get('.bi-list').click()
        cy.get('.nav > :nth-child(2) > .nav-link').click()
        cy.wait(2000)
        
        // Client Name
        cy.get('#clientName').find('option').then(options => {
        const op = options.length;
        const clientName = faker.random.number({ min: 1, max: op - 1 });
        cy.get('#clientName').select(clientName);
        });
        
        // Shift
        cy.get('#shift').find('option').then(options => {
        const op = options.length;
        const shift = faker.random.number({ min: 1, max: op - 1 });
        cy.get('#shift').select(shift);
        });

        // Start Time
        cy.get('#startTime').type('09:30')

        // End Time
        cy.get('#endTime').type('06:30')

        // Start Date
        cy.get('#startDate').type('2023-10-01')

        // End Date
        cy.get('#endDate').type('2023-10-30')

        // Image Upload
        ft.imageUpload()

        // Location
        cy.get('#location').find('option').then(options => {
        const op = options.length;
        const shift = faker.random.number({ min: 1, max: op - 1 });
        cy.get('#location').select(shift);
        });
        
        

    })
})
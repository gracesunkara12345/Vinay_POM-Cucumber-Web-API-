import faker from 'faker';
import ViewHistory from "../../POMObjects/User/ViewHistoryOb"
describe('View History', () => {
    it('View History in User', () => {

     const vh = new ViewHistory()
     vh.visitViewHistory()
     
     // Search Client
    //  const clientName = ['cognizant', 'deloitte', 'saint',  'seimens']
    //  const randomClient = clientName[Math.floor(Math.random() * clientName.length)]
    //  cy.get('label > input').type(randomClient)

    // const approvedFile = faker.random.number({min: 1, max: 8})
    //  cy.get(`:nth-child(${approvedFile}) > :nth-child(8) > a`).trigger('click', { force: true });

    })
})
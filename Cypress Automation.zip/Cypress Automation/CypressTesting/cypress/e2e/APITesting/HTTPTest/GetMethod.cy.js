describe("Get Request", () => {
    it("Get Request in API", () => {

        cy.request('GET', 'https://reqres.in/api/users?page=2')
        .its('status')
        .should('equal', 200);

    })

})
/// <reference types="cypress" />

const goOffline = () => {
    cy.log("**go offline**")
      .then(() => {
        Cypress.automation("remote:debugger:protocol", {
          command: "Network.enable",
        });
      })
      .then(() => {
        Cypress.automation("remote:debugger:protocol", {
          command: "Network.emulateNetworkConditions",
          params: {
            offline: true,
            latency: -1,
            downloadThroughput: -1,
            uploadThroughput: -1,
          },
        });
      });
  };
  
  const goOnline = () => {
    cy.log("**go online**")
      .then(() => {
        Cypress.automation("remote:debugger:protocol", {
          command: "Network.emulateNetworkConditions",
          params: {
            offline: false,
            latency: -1,
            downloadThroughput: -1,
            uploadThroughput: -1,
          },
        });
      })
      .then(() => {
        Cypress.automation("remote:debugger:protocol", {
          command: "Network.disable",
        });
      });
  };
  
  describe("app", () => {
    it("should render online text when online", () => {
        //goOnline();
       // goOffline();
        cy.visit('http://192.168.3.106:8890/login')
        cy.get('#username').type('pavithra.resoju@ojas-it.com')
        cy.get('#password').type('Ojas@1525')
        goOffline();
        cy.get('.btn').click()
        
      //goOnline();
    });
  
    // it("should render offline text when offline", () => {
    //   goOffline();
    //   cy.visit('http://192.168.3.106:8890/login')
    //     cy.get('#username').type('pavithra.resoju@ojas-it.com')
    //     cy.get('#password').type('Ojas@1525')
    //     cy.get('.btn').click()
    //   goOnline();
    // });
  
    // it("should not render online text when offline", () => {
    //   goOffline();
    //   cy.visit('http://192.168.3.106:8890/login')
    //     cy.get('#username').type('pavithra.resoju@ojas-it.com')
    //     cy.get('#password').type('Ojas@1525')
    //     cy.get('.btn').click()
    //   goOnline();
    // });
  });
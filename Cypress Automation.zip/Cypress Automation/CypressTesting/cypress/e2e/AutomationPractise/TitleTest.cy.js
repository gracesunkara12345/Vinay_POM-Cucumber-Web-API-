describe('Login Test', () => {
    Cypress.Screenshot.defaults({
        screenshotOnRunFailure: true,
      });
    it('Login with mutiple data', () => {
        cy.visit('https://adactinhotelapp.com/')
        const title =  cy.title()
        cy.log(title);
        const url = cy.url()
        cy.log(url)
        cy.get('#username').type('veerasubbu')
        cy.screenshot()
        cy.get('#passwrd').type('avc')
        })
    })
  
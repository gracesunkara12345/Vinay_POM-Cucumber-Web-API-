describe('Login Test', () => {
    it('Login with mutiple data', () => {
        cy.visit('https://adactinhotelapp.com/')
        cy.fixture('users.json').then((data) => {
        cy.get('#username').type(data[1].username)
        cy.get('#password').type(data[1].password)
        cy.get('#login').click()
        })
    })
  })
describe('Login Test', () => {
    it('Login with mutiple data', () => {
        cy.visit('https://adactinhotelapp.com/')

        // Alias 
        cy.get('#username').as('user')
        cy.get('@user').type('veerasubbu')
        cy.get('#password').as('pass')
        cy.get('@pass').type('veerasubbu')
        cy.get('#login').click()
        })
    })
  
describe('Login Test', () => {
    it('Login with mutiple data', () => {
         cy.visit('https://adactinhotelapp.com/')
         cy.get('#username').type('veerasubbu')
         cy.get('#password').type('veerasubbu')
         cy.get('#login').click()
         cy.get('[href="BookedItinerary.php"]').click()

         // back
         cy.go('back')

         // forward
         cy.go('forward')

         // reload
         cy.reload()
    })
})
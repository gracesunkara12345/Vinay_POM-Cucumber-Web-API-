import faker from 'faker';

describe('Your Test Suite', () => {
  it('Generates a New Client Name', () => {
    const clientName = faker.company.companyName()
    cy.log(`Generated Client Name: ${clientName}`);

  });
});

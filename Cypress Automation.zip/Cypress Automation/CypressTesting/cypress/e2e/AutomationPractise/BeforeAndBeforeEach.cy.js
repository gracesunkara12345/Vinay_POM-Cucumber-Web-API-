describe('My Test Suite', () => {
    beforeEach(() => {
        cy.visit('https://adactinhotelapp.com/')
    });

    afterEach(() => {
        cy.get('[href="Logout.php"]').click()
        cy.get('.reg_success > a').click()
    })
  
    it('Test 1', () => {
        cy.get('#username').type('veerasubbu')
        cy.get('#password').type('veerasubbu')
        cy.get('#login').click()
    });
  
    it('Test 2', () => {
        cy.get('#username').type('vinaychennuri1')
        cy.get('#password').type('K635K8')
        cy.get('#login').click()
    });
  });
  
import 'cypress-file-upload';
describe('Image Upload', () => {
    it('Verify the image upload', () => {
      cy.visit('https://the-internet.herokuapp.com/upload')
      cy.wait(2000)
      
      cy.fixture('doc.png').then((fileContent) => {
        cy.get('#file-upload').attachFile({
          fileContent,
          fileName: 'doc.png',
          mimeType: 'image/jpg',
        });
      });
      cy.get('#file-submit').click()
    })
  })
package PageObjects;

public interface OrgObjects {
	
	String org = "//a[text()='Organizations ']"; // Xpath
	String addOrg = "//a[text()='Add Organization']"; // Xpath
	String search = "//input[@placeholder='Search...']"; // Xpath
	
	String orgName = "organizationName"; // id
	String code = "countryCode";  // id
	String phone = "phone"; // Name
	String website = "//input[@placeholder='Enter website']"; // Xpath
	String empSize = "employeeSize"; // Name
	String revenue = "revenue"; // Name
	String location = "location"; // Name
	
	String save = "//button[text()='Save']"; // Xpath
	String cancel = "//button[text()='Cancel']"; // Xpath
	
	

}

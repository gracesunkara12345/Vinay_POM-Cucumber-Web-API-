package PageObjects;

public interface LoginObjects {
	
	String username = "email";
	String password = "password";
	String signInButton = "//button[text()=' Login']";

}

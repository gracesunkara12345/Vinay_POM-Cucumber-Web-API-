package PageObjects;

public interface ContactsObjects {
	
	String contacts = "//*[text()='Contacts ']"; // XPATH
	String addcontact = "//a[text()='Add Contact']"; //XPATH
	
	String orgName = "formrow-inputState organizationName"; // ID
	String contactName = "contactName"; // ID
	String title = "Title"; // ID
	String email = "personalEmail"; // ID
	String officalEmail = "officialEmail"; // ID
	String linkedin = "linkedIn"; // ID
	String personalPhone = "personalPhone"; // Name
	String officalPhone = "officialPhone"; // Name
	String flatNo = "flatNo"; // Name
	String buildingName = "buildingName"; // Name
	String street = "street"; // Name
	String city = "city";
    String State = "formrow-inputState"; // ID
    String pinCode = "pinCode"; // Name
    
    String contactsCount = "//span[@class ='p-paginator-current ng-star-inserted']"; //Xpath
    
    String save = "//button[text()='Save']"; // XPATH
    String cancel = "//button[text()='Cancel']"; // XPATH
   
}

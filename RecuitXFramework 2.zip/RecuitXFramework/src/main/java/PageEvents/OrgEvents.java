package PageEvents;

import java.util.concurrent.TimeUnit;

import org.testng.Assert;

import Base.BaseTest;
import PageObjects.OrgObjects;
import Utils.ElementFetch; 

public class OrgEvents {
	
	ElementFetch ele = new ElementFetch();
	
	public void visitOrg() throws Exception
	{
		Thread.sleep(5000);
		ele.getWebElement("XPATH", OrgObjects.org).click();
		ele.getWebElement("XPATH", OrgObjects.addOrg).click();
		BaseTest.driver.manage().timeouts().implicitlyWait(5000, TimeUnit.SECONDS);
	}
	
	public void createOrg()
	{
		ele.getWebElement("ID", OrgObjects.orgName).sendKeys("Ojas");
		ele.getWebElement("NAME", OrgObjects.phone).sendKeys("9381842462");
		ele.getWebElement("XPATH", OrgObjects.website).sendKeys("www.ojas-it.com");
		ele.getWebElement("NAME", OrgObjects.empSize).sendKeys("300");
		ele.getWebElement("NAME", OrgObjects.revenue).sendKeys("5000000");
		ele.getWebElement("NAME", OrgObjects.location).sendKeys("Hyderabad");
		ele.getWebElement("XPATH", OrgObjects.save).click();
		
	}
	
	public void cancelOrg()
	{
		ele.getWebElement("ID", OrgObjects.orgName).sendKeys("Ojas");
		ele.getWebElement("NAME", OrgObjects.phone).sendKeys("9381842462");
		ele.getWebElement("XPATH", OrgObjects.website).sendKeys("www.ojas-it.com");
		ele.getWebElement("NAME", OrgObjects.empSize).sendKeys("300");
		ele.getWebElement("NAME", OrgObjects.revenue).sendKeys("5000000");
		ele.getWebElement("NAME", OrgObjects.location).sendKeys("Hyderabad");
		ele.getWebElement("XPATH", OrgObjects.cancel).click();
		
	}
	
	public void searchOrg()
	{
		Assert.assertEquals(true, false);
		ele.getWebElement("XPATH", OrgObjects.search).sendKeys("Ojas");
	}

}

package PageEvents;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;

import Base.BaseTest;
import PageObjects.ContactsObjects;
import Utils.ElementFetch;
import com.github.javafaker.Faker;
import java.util.Random;
import Utils.ReusableMethods;
import org.openqa.selenium.WebElement;

public class ContactsEvents {
	
	ReusableMethods reuse = new ReusableMethods();
	ElementFetch ele = new ElementFetch();
	Faker faker = new Faker();
	
	public void visitContacts()
	{
		ele.getWebElement("XPATH", ContactsObjects.contacts).click();
		BaseTest.driver.manage().timeouts().implicitlyWait(5000, TimeUnit.SECONDS);
	}
	
	public void addContacts()
	{
		ele.getWebElement("XPATH", ContactsObjects.addcontact).click();
	}
	
	public void createContact()
	{
		// Faker Data
		String contactName = faker.name().firstName();
		String lastName = faker.name().lastName();
		String lastName1 = faker.name().lastName();
		String title = faker.name().title();
		Random random = new Random();
	    int orgNum = random.nextInt(10) + 1; 
	    String personalPhone = "9" + faker.number().digits(9);
	    String officialPhone = "8" + faker.number().digits(9);
	    String flatNum = faker.address().buildingNumber();
	    String buildingName = faker.address().streetName();
	    String city = faker.address().city();
	    int state = random.nextInt(10) + 1;
	    String pinCode = "5" + faker.number().digits(5);

		Select orgaName = new Select(BaseTest.driver.findElement(By.id(ContactsObjects.orgName)));
		orgaName.selectByIndex(orgNum);
		ele.getWebElement("ID", ContactsObjects.contactName).sendKeys(contactName);
		ele.getWebElement("ID", ContactsObjects.title).sendKeys(title);
		ele.getWebElement("ID", ContactsObjects.email).sendKeys(contactName + "." + lastName + "@gmail.com");
		ele.getWebElement("ID", ContactsObjects.officalEmail).sendKeys(contactName + "." + lastName1 + "@gmail.com");
		ele.getWebElement("ID", ContactsObjects.linkedin).sendKeys(contactName);
		ele.getWebElement("NAME", ContactsObjects.personalPhone).sendKeys(personalPhone);
		ele.getWebElement("NAME", ContactsObjects.officalPhone).sendKeys(officialPhone);
		ele.getWebElement("NAME", ContactsObjects.flatNo).sendKeys(flatNum);
		ele.getWebElement("NAME", ContactsObjects.buildingName).sendKeys(buildingName);
		ele.getWebElement("NAME", ContactsObjects.street).sendKeys(buildingName);
		ele.getWebElement("NAME", ContactsObjects.city).sendKeys(city);
		Select states = new Select(BaseTest.driver.findElement(By.id(ContactsObjects.State)));
		states.selectByIndex(state);
		ele.getWebElement("NAME", ContactsObjects.pinCode).sendKeys(pinCode);
		ele.getWebElement("XPATH", ContactsObjects.save).click();
		
	}
	
	public void deleteContacts() throws Exception
	{
		reuse.scrollDown();
		Thread.sleep(3000);
		WebElement ContactCount = ele.getWebElement("XPATH", ContactsObjects.contactsCount);
		String text = ContactCount.getText();
		int startIndex = text.indexOf("of") + 3;
	    int endIndex = text.indexOf("entries");
	    String result = text.substring(startIndex, endIndex).trim();
	    System.out.println(result);
	}

}

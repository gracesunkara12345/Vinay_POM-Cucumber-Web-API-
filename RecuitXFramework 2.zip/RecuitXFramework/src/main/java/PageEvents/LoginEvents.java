package PageEvents;
import PageObjects.LoginObjects;
import Utils.Constants;
import Utils.ElementFetch;

public class LoginEvents {
	
	ElementFetch ele = new ElementFetch();
	
	public void loginPage()
	{
		ele.getWebElement("NAME", LoginObjects.username).sendKeys(Constants.username);
		ele.getWebElement("NAME", LoginObjects.password).sendKeys(Constants.password);
		ele.getWebElement("XPATH", LoginObjects.signInButton).click();
	}

}

package Utils;

public interface Constants{
	
    String URL = "http://192.168.1.65:8080/Recruitex_Sales/#/login";
	String username = "jayaram.yedla@ojas-it.com";
	String password = "8897503250";

}

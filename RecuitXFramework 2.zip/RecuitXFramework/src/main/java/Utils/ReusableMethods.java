package Utils;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import com.google.common.io.Files;

import Base.BaseTest;

public class ReusableMethods extends BaseTest{
	
	public String addScreenshot(String fileName)
	{
		TakesScreenshot ts = (TakesScreenshot)driver;
		File srcFile = ts.getScreenshotAs(OutputType.FILE);
		File desFile = new File("./screenshots/"+ fileName + ".jpg");
		try {
			Files.copy(srcFile, desFile);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return desFile.getAbsolutePath();
	}
	
	public void scrollDown()
	{
		JavascriptExecutor js = (JavascriptExecutor)BaseTest.driver;
		js.executeScript("window.scrollBy(0,500)");
	}

}

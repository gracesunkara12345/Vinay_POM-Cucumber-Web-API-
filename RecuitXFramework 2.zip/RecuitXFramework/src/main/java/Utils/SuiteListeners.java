package Utils;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;
import com.google.common.io.Files;
import Base.BaseTest;

public class SuiteListeners extends TestListenerAdapter  {

	@Override
	public void onTestFailure(ITestResult tr) {
		TakesScreenshot ts = (TakesScreenshot)BaseTest.driver;
		File srcFile = ts.getScreenshotAs(OutputType.FILE);
		File desFile = new File("./failedScreenshot/" + tr.getName()+ "_failedsc.jpg");
		try {
			Files.copy(srcFile, desFile);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

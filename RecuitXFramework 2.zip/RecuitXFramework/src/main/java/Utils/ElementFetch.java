package Utils;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import Base.BaseTest;

public class ElementFetch {
	
	public WebElement getWebElement(String ObjectType, String ObjectValue)
	{
       switch(ObjectType)
       {
       case "XPATH":
       return BaseTest.driver.findElement(By.xpath(ObjectValue));
       
       case "ID":
       return BaseTest.driver.findElement(By.id(ObjectValue));
           
       case "NAME":
       return BaseTest.driver.findElement(By.name(ObjectValue));
           
       case "TAG":
       return BaseTest.driver.findElement(By.tagName(ObjectValue));
       
       case "CSS":
       return BaseTest.driver.findElement(By.cssSelector(ObjectValue));
       
       case "LINKTEXT":
       return BaseTest.driver.findElement(By.linkText(ObjectValue));
       
       default:
       return null;
       }
	}

}

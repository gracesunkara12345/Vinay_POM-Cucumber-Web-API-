package Base;

import java.util.concurrent.TimeUnit;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import Utils.Constants;
import io.github.bonigarcia.wdm.WebDriverManager;
import Utils.ReusableMethods;


public class BaseTest {

	public static ExtentReports extent;
	public static ExtentHtmlReporter html;
	public static ExtentTest test;
	public static WebDriver driver;
	protected static final Logger LOG = (Logger) LogManager.getLogger(BaseTest.class);
	ReusableMethods reuse = new ReusableMethods();

	
	@BeforeSuite
	public void reportsGeneration() {
		extent = new ExtentReports();
		html = new ExtentHtmlReporter("./reports/" + "extent.html");
		extent.attachReporter(html);
	}

	@BeforeMethod
	@Parameters("browser")
	public void browserLaunch(String browser) {
		setupBrowser(browser);
		driver.manage().window().maximize();
		driver.get(Constants.URL);
		driver.manage().timeouts().implicitlyWait(10000, TimeUnit.SECONDS);
	}

	@AfterMethod
	public void logResult(ITestResult result) throws Exception {
		if (result.getStatus() == ITestResult.FAILURE) {
			System.out.println(test.fail(result.getName()));
			test.fail(result.getName(), MediaEntityBuilder.createScreenCaptureFromPath(reuse.addScreenshot(result.getName())).build());
		} else if (result.getStatus() == ITestResult.SKIP) {
			System.out.println(test.skip(result.getName()));
			test.skip(result.getName(), MediaEntityBuilder.createScreenCaptureFromPath(reuse.addScreenshot(result.getName())).build());
		} else if (result.getStatus() == ITestResult.SUCCESS) {
			System.out.println(test.pass(result.getName()));
			test.pass(result.getName(), MediaEntityBuilder.createScreenCaptureFromPath(reuse.addScreenshot(result.getName())).build());

		}
		driver.close();
	}

	@AfterSuite
	public void tearDown() {
		extent.flush();
	}

	public void setupBrowser(String browser) {
		if (browser.equalsIgnoreCase("chrome")) {
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
		}
		if (browser.equalsIgnoreCase("edge")) {
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
		}
		if (browser.equalsIgnoreCase("firefox")) {
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
		}
	}

}

package DeleteData;

import org.testng.annotations.Test;
import com.aventstack.extentreports.MediaEntityBuilder;
import Base.BaseTest;
import PageEvents.LoginEvents;
import PageEvents.ContactsEvents;
import Utils.ReusableMethods;

public class DeleteContacts extends BaseTest {
	
	LoginEvents login = new LoginEvents();
	ContactsEvents con = new ContactsEvents();
	ReusableMethods reuse = new ReusableMethods();
	
	@Test
	public void deleteContactsData() throws Exception
	{
		test = extent.createTest("DeleteContacts")
		      .assignCategory("FunctionalTest")
		      .assignAuthor("Vinay");
		LOG.info("Chrome Driver initialization");
		login.loginPage();
		LOG.info("Visited HomePage");
		test.pass("LoginPage", MediaEntityBuilder.createScreenCaptureFromPath(reuse.addScreenshot("LoginPage")).build());
		con.visitContacts();
		LOG.info("Visited ContactsPage");
		test.pass("ContactsPage", MediaEntityBuilder.createScreenCaptureFromPath(reuse.addScreenshot("ContactsPage")).build());
		Thread.sleep(3000);
        con.deleteContacts();
		LOG.info("Contacts Deleted Successfully");
		test.pass("Contacts Delete", MediaEntityBuilder.createScreenCaptureFromPath(reuse.addScreenshot("ContactsDelete")).build());


		
	}

}

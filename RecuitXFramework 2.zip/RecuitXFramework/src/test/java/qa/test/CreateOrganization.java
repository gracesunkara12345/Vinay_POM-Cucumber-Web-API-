package qa.test;

import org.testng.annotations.Test;
import com.aventstack.extentreports.MediaEntityBuilder;
import Base.BaseTest;
import PageEvents.OrgEvents;
import PageEvents.LoginEvents;
import Utils.ReusableMethods;

public class CreateOrganization extends BaseTest{
	
	LoginEvents login = new LoginEvents();
	OrgEvents org = new OrgEvents();
	ReusableMethods reuse = new ReusableMethods();

	
	@Test
	public void createOrgData() throws Exception
	{
		test = extent.createTest("CreateOrganization")
		      .assignCategory("Functional Test")
		      .assignAuthor("Vinay");
		LOG.info("Browser Initialize");
		login.loginPage();
		test.pass("LoginPage", MediaEntityBuilder.createScreenCaptureFromPath(reuse.addScreenshot("LoginPage")).build());
		LOG.info("Visited HomPage");
		test.pass("HomePage", MediaEntityBuilder.createScreenCaptureFromPath(reuse.addScreenshot("HomePage")).build());
		org.visitOrg();
		LOG.info("Visited OrganizationPage");
		test.pass("OrgPage", MediaEntityBuilder.createScreenCaptureFromPath(reuse.addScreenshot("OrgPage")).build());
		org.createOrg();
		LOG.info("org data");
		test.pass("OrgData", MediaEntityBuilder.createScreenCaptureFromPath(reuse.addScreenshot("OrgData")).build());

	}

}

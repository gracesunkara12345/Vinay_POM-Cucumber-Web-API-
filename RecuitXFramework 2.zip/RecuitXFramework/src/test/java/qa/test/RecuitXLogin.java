package qa.test;


import org.testng.annotations.Test;
import com.aventstack.extentreports.MediaEntityBuilder;
import Base.BaseTest;
import PageEvents.LoginEvents;
import Utils.ReusableMethods;

public class RecuitXLogin extends BaseTest {
	
	LoginEvents login = new LoginEvents();
	ReusableMethods reuse = new ReusableMethods();
	
	@Test
	public void GreytHRLogin() throws Exception
	{
		test = extent.createTest("RecuitXLogin")
		      .assignCategory("FunctionalTest")
		      .assignAuthor("Shivani");
		LOG.info("RecuitX Login Page");
		login.loginPage();
		LOG.info("RecuitX Login Successfull");
		test.pass("RecuitX Login", MediaEntityBuilder.createScreenCaptureFromPath(reuse.addScreenshot("RecuitXLoginPage")).build());
		LOG.info("Driver close");
		
	}

}

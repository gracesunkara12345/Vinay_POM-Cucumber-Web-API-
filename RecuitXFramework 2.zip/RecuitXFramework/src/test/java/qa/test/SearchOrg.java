package qa.test;

import org.testng.annotations.Test;

import com.aventstack.extentreports.MediaEntityBuilder;
import Base.BaseTest;
import PageEvents.LoginEvents;
import PageEvents.OrgEvents;
import Utils.ReusableMethods;

public class SearchOrg extends BaseTest {
	
	LoginEvents login = new LoginEvents();
	OrgEvents org = new OrgEvents();
	ReusableMethods reuse = new ReusableMethods();
	
	@Test
	public void searchOrganization() throws Exception
	{
		test = extent.createTest("SearchOrganization")
			      .assignCategory("Functional Test")
			      .assignAuthor("Mohan");
			LOG.info("Browser Initialize");
			login.loginPage();
			test.pass("LoginPage", MediaEntityBuilder.createScreenCaptureFromPath(reuse.addScreenshot("LoginPage1")).build());
			LOG.info("Visited HomPage");
			test.pass("HomePage", MediaEntityBuilder.createScreenCaptureFromPath(reuse.addScreenshot("HomePage1")).build());
			org.visitOrg();
			LOG.info("Visited OrganizationPage");
			test.fail("SearchPage", MediaEntityBuilder.createScreenCaptureFromPath(reuse.addScreenshot("searchOrg")).build());
			LOG.warn("Test Failed");
			org.searchOrg();
	}
	

}

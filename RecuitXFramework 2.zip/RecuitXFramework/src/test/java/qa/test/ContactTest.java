package qa.test;

import java.io.IOException;

import org.testng.annotations.Test;

import com.aventstack.extentreports.MediaEntityBuilder;

import Base.BaseTest;
import PageEvents.LoginEvents;
import PageEvents.ContactsEvents;
import Utils.ReusableMethods;

public class ContactTest extends BaseTest {
	
	LoginEvents login = new LoginEvents();
	ContactsEvents con = new ContactsEvents();
	ReusableMethods reuse = new ReusableMethods();
	
	@Test
	public void testContactPage() throws Exception
	{
		test = extent.createTest("ContactPage")
		      .assignCategory("Functinal Testing")
		      .assignAuthor("Vinay");
		LOG.info("Initialize Browser");
		login.loginPage();
		LOG.info("Login Successfull");
		test.pass("LoginPage", MediaEntityBuilder.createScreenCaptureFromPath(reuse.addScreenshot("LoginPage")).build());
		con.visitContacts();
		LOG.info("Visited Contacts");
		Thread.sleep(3000);
		test.pass("ContactPage", MediaEntityBuilder.createScreenCaptureFromPath(reuse.addScreenshot("ContactPage")).build());
        con.createContact();
        LOG.info("Contact Created Successfully");
		test.pass("ContactCreated", MediaEntityBuilder.createScreenCaptureFromPath(reuse.addScreenshot("ContactCreated")).build());
		
	}

}

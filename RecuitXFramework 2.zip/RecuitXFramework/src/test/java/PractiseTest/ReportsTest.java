package PractiseTest;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class ReportsTest {
	
	public ExtentReports extent;
	public ExtentHtmlReporter html;
	
	@BeforeTest
	public void reportGenerate()
	{
		extent = new ExtentReports();
		html = new ExtentHtmlReporter("./reports/" + "extentReports.html");
		extent.attachReporter(html);
	}
	
	@AfterTest
	public void tearDown()
	{
		extent.flush();
	}

}

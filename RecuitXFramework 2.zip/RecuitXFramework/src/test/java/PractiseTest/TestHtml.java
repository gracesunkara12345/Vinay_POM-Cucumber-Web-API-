package PractiseTest;

import org.testng.annotations.Test;

public class TestHtml extends ReportsTest {
	
	@Test
	public void report1()
	{
		extent.createTest("Sara");
	}

}
